from __future__ import annotations

import io
import random
import socket
import struct
import threading
import time

from PIL import Image

from wiiu_stream.protocol import (
    FLAG_NO_FRAME_CRC,
    VERSION,
    VIDEO_HEADER_SIZE,
    VIDEO_MAGIC,
    VIDEO_PAYLOAD_SIZE,
)


def make_jpeg() -> bytes:
    image = Image.new("RGB", (854, 480), (40, 90, 160))
    output = io.BytesIO()
    image.save(output, format="JPEG", quality=34, subsampling=2)
    image.close()
    return output.getvalue()


def send_frame(port: int = 9445) -> None:
    jpeg = make_jpeg()
    chunks = [jpeg[i:i + VIDEO_PAYLOAD_SIZE] for i in range(0, len(jpeg), VIDEO_PAYLOAD_SIZE)]
    packets: list[bytes] = []
    for index, payload in enumerate(chunks):
        header = struct.pack(
            ">IBBBBIIIHHHHHBB",
            VIDEO_MAGIC,
            VERSION,
            0,
            FLAG_NO_FRAME_CRC,
            VIDEO_HEADER_SIZE,
            1,
            len(jpeg),
            0,
            index,
            len(chunks),
            len(payload),
            854,
            480,
            34,
            0,
        )
        packets.append(header + payload)
    random.Random(5).shuffle(packets)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for packet in packets:
        sock.sendto(packet, ("127.0.0.1", port))
    sock.close()
    print(f"Image test envoyée : {len(jpeg)} octets, {len(chunks)} paquets")


if __name__ == "__main__":
    time.sleep(0.2)
    send_frame()
