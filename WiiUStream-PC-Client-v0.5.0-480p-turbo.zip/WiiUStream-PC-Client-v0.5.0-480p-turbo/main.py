from __future__ import annotations

import tkinter as tk

from wiiu_stream.app import WiiUStreamApp


def main() -> None:
    root = tk.Tk()
    WiiUStreamApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
