# Protocole WiiUStream v2

Le client PC utilise exactement le protocole du plugin Aroma v0.5.0.

- contrôle UDP : `9444`
- vidéo UDP : `9445`
- paquet de présence : `WUSC`, version 2, 12 octets
- vidéo : `WUSV`, en-tête de 32 octets
- charge JPEG maximale par paquet : 1440 octets
- image attendue : 854 × 480
- drapeau `0x01` obligatoire : pas de CRC complet de l’image

Les plugins v1/v0.4 et antérieurs ne sont pas compatibles avec ce client.
