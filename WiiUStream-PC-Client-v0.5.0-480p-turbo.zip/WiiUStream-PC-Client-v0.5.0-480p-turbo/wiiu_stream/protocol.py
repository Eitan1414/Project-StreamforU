from __future__ import annotations

import ipaddress
import struct
from dataclasses import dataclass
from typing import Final

CONTROL_MAGIC: Final = 0x57555343  # WUSC
VIDEO_MAGIC: Final = 0x57555356  # WUSV
VERSION: Final = 2
HELLO_TYPE: Final = 1
CONTROL_PORT: Final = 9444
DEFAULT_VIDEO_PORT: Final = 9445
CONTROL_PACKET_SIZE: Final = 12
VIDEO_HEADER_SIZE: Final = 32
FLAG_NO_FRAME_CRC: Final = 0x01
VIDEO_PAYLOAD_SIZE: Final = 1440
MAX_DATAGRAM_SIZE: Final = VIDEO_HEADER_SIZE + VIDEO_PAYLOAD_SIZE
MAX_FRAME_SIZE: Final = 512 * 1024
MAX_CHUNK_COUNT: Final = 512
FRAME_TIMEOUT_SECONDS: Final = 0.120
EXPECTED_WIDTH: Final = 854
EXPECTED_HEIGHT: Final = 480

_CONTROL_STRUCT = struct.Struct(">IBBHI")
_VIDEO_HEADER_STRUCT = struct.Struct(">IBBBBIIIHHHHHBB")


@dataclass(frozen=True, slots=True)
class VideoHeader:
    stream: int
    frame_id: int
    frame_size: int
    chunk_index: int
    chunk_count: int
    payload_size: int
    width: int
    height: int
    jpeg_quality: int


def hello_packet(video_port: int = DEFAULT_VIDEO_PORT) -> bytes:
    if not 1 <= video_port <= 65535:
        raise ValueError("Le port vidéo doit être compris entre 1 et 65535.")
    return _CONTROL_STRUCT.pack(
        CONTROL_MAGIC,
        VERSION,
        HELLO_TYPE,
        video_port,
        0,
    )


def parse_video_header(buffer: bytes | bytearray | memoryview, packet_length: int) -> VideoHeader | None:
    """Parse a v2 header without allocating a payload object."""
    if packet_length < VIDEO_HEADER_SIZE or packet_length > MAX_DATAGRAM_SIZE:
        return None

    (
        magic,
        version,
        stream,
        flags,
        header_size,
        frame_id,
        frame_size,
        frame_crc32,
        chunk_index,
        chunk_count,
        payload_size,
        width,
        height,
        jpeg_quality,
        reserved,
    ) = _VIDEO_HEADER_STRUCT.unpack_from(buffer, 0)

    if magic != VIDEO_MAGIC or version != VERSION or header_size != VIDEO_HEADER_SIZE:
        return None
    if stream not in (0, 1):
        return None
    if flags != FLAG_NO_FRAME_CRC or reserved != 0 or frame_crc32 != 0:
        return None
    if not 1 <= frame_size <= MAX_FRAME_SIZE:
        return None
    if not 1 <= chunk_count <= MAX_CHUNK_COUNT or chunk_index >= chunk_count:
        return None
    if not 1 <= payload_size <= VIDEO_PAYLOAD_SIZE:
        return None
    if payload_size > packet_length - VIDEO_HEADER_SIZE:
        return None
    if width != EXPECTED_WIDTH or height != EXPECTED_HEIGHT:
        return None
    if not 20 <= jpeg_quality <= 55:
        return None

    expected_chunk_count = (frame_size + VIDEO_PAYLOAD_SIZE - 1) // VIDEO_PAYLOAD_SIZE
    if chunk_count != expected_chunk_count:
        return None

    destination_offset = chunk_index * VIDEO_PAYLOAD_SIZE
    expected_payload_size = min(VIDEO_PAYLOAD_SIZE, frame_size - destination_offset)
    if destination_offset < 0 or expected_payload_size <= 0 or payload_size != expected_payload_size:
        return None

    return VideoHeader(
        stream=stream,
        frame_id=frame_id,
        frame_size=frame_size,
        chunk_index=chunk_index,
        chunk_count=chunk_count,
        payload_size=payload_size,
        width=width,
        height=height,
        jpeg_quality=jpeg_quality,
    )


def is_newer_frame(candidate: int, reference: int) -> bool:
    distance = (candidate - reference) & 0xFFFFFFFF
    return 0 < distance < 0x80000000


def validate_ipv4(value: str) -> str:
    cleaned = value.strip()
    try:
        address = ipaddress.ip_address(cleaned)
    except ValueError as exc:
        raise ValueError("Adresse IPv4 invalide.") from exc
    if address.version != 4:
        raise ValueError("Une adresse IPv4 est nécessaire.")
    return str(address)
