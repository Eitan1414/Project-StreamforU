from __future__ import annotations

import json
import os
from pathlib import Path


def _settings_path() -> Path:
    base = os.environ.get("APPDATA")
    if base:
        root = Path(base)
    else:
        root = Path.home() / ".config"
    return root / "WiiUStream" / "settings.json"


def load_ip() -> str:
    path = _settings_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return ""
    value = data.get("wiiu_ip")
    return value if isinstance(value, str) else ""


def save_ip(ip_address: str) -> None:
    path = _settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"wiiu_ip": ip_address}, indent=2), encoding="utf-8")
