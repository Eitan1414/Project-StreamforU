"""WiiUStream PC client — protocol v2."""

__version__ = "0.5.0"
