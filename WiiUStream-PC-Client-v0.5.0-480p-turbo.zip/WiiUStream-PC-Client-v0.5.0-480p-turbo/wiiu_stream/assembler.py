from __future__ import annotations

import queue
import time
from dataclasses import dataclass

from .protocol import (
    FRAME_TIMEOUT_SECONDS,
    MAX_FRAME_SIZE,
    VIDEO_HEADER_SIZE,
    VIDEO_PAYLOAD_SIZE,
    VideoHeader,
    is_newer_frame,
)


class JpegBufferPool:
    """Small fixed pool to avoid allocating a large bytearray for every frame."""

    def __init__(self, maximum: int = 4) -> None:
        self._pool: queue.LifoQueue[bytearray] = queue.LifoQueue(maxsize=maximum)

    def acquire(self) -> bytearray:
        try:
            return self._pool.get_nowait()
        except queue.Empty:
            return bytearray(MAX_FRAME_SIZE)

    def release(self, buffer: bytearray | None) -> None:
        if buffer is None or len(buffer) != MAX_FRAME_SIZE:
            return
        try:
            self._pool.put_nowait(buffer)
        except queue.Full:
            pass

    def clear(self) -> None:
        while True:
            try:
                self._pool.get_nowait()
            except queue.Empty:
                return


@dataclass(slots=True)
class EncodedFrame:
    jpeg: bytearray
    jpeg_size: int
    stream: int
    frame_id: int
    width: int
    height: int
    jpeg_quality: int


@dataclass(slots=True)
class _PendingFrame:
    header: VideoHeader
    jpeg: bytearray
    created_at: float
    received: bytearray
    received_chunks: int = 0
    received_bytes: int = 0

    def matches(self, other: VideoHeader) -> bool:
        original = self.header
        return (
            original.frame_id == other.frame_id
            and original.frame_size == other.frame_size
            and original.chunk_count == other.chunk_count
            and original.stream == other.stream
            and original.width == other.width
            and original.height == other.height
            and original.jpeg_quality == other.jpeg_quality
        )


class FrameAssembler:
    """Retains only the newest incomplete frame for each output stream."""

    def __init__(self, pool: JpegBufferPool) -> None:
        self._pool = pool
        self._pending: dict[int, _PendingFrame] = {}
        self._newest_seen: dict[int, int] = {}
        self.timed_out_frames = 0
        self.invalid_frames = 0
        self.stale_frames = 0

    def accept(
        self,
        header: VideoHeader,
        datagram: bytes | bytearray | memoryview,
    ) -> EncodedFrame | None:
        now = time.monotonic()
        self.cleanup_expired(now)

        newest = self._newest_seen.get(header.stream)
        if newest is None:
            self._newest_seen[header.stream] = header.frame_id
        elif is_newer_frame(header.frame_id, newest):
            self._newest_seen[header.stream] = header.frame_id
            stale = self._pending.pop(header.stream, None)
            if stale is not None:
                self._pool.release(stale.jpeg)
                self.stale_frames += 1
        elif header.frame_id != newest:
            return None

        pending = self._pending.get(header.stream)
        if pending is None or pending.header.frame_id != header.frame_id:
            pending = _PendingFrame(
                header=header,
                jpeg=self._pool.acquire(),
                created_at=now,
                received=bytearray(header.chunk_count),
            )
            self._pending[header.stream] = pending
        elif not pending.matches(header):
            self._pending.pop(header.stream, None)
            self._pool.release(pending.jpeg)
            self.invalid_frames += 1
            return None

        if pending.received[header.chunk_index] == 0:
            destination_offset = header.chunk_index * VIDEO_PAYLOAD_SIZE
            destination_end = destination_offset + header.payload_size
            if destination_end > header.frame_size:
                self._pending.pop(header.stream, None)
                self._pool.release(pending.jpeg)
                self.invalid_frames += 1
                return None

            source_start = VIDEO_HEADER_SIZE
            source_end = source_start + header.payload_size
            pending.jpeg[destination_offset:destination_end] = datagram[source_start:source_end]
            pending.received[header.chunk_index] = 1
            pending.received_chunks += 1
            pending.received_bytes += header.payload_size

        if pending.received_chunks != pending.header.chunk_count:
            return None

        self._pending.pop(header.stream, None)
        if pending.received_bytes != pending.header.frame_size:
            self._pool.release(pending.jpeg)
            self.invalid_frames += 1
            return None

        return EncodedFrame(
            jpeg=pending.jpeg,
            jpeg_size=pending.header.frame_size,
            stream=pending.header.stream,
            frame_id=pending.header.frame_id,
            width=pending.header.width,
            height=pending.header.height,
            jpeg_quality=pending.header.jpeg_quality,
        )

    def cleanup_expired(self, now: float | None = None) -> None:
        current = time.monotonic() if now is None else now
        expired = [
            stream
            for stream, frame in self._pending.items()
            if current - frame.created_at > FRAME_TIMEOUT_SECONDS
        ]
        for stream in expired:
            frame = self._pending.pop(stream)
            self._pool.release(frame.jpeg)
            self.timed_out_frames += 1

    def clear(self) -> None:
        for frame in self._pending.values():
            self._pool.release(frame.jpeg)
        self._pending.clear()
        self._newest_seen.clear()
