from __future__ import annotations

import queue
import tkinter as tk
from tkinter import messagebox, ttk

from PIL import Image, ImageTk

from .protocol import validate_ipv4
from .receiver import DecodedFrame, StreamReceiver
from .settings import load_ip, save_ip

BACKGROUND = "#10151d"
PANEL = "#18212d"
TEXT = "#f4f7fb"
SECONDARY = "#aeb9c8"
ERROR = "#ff6b6b"


class WiiUStreamApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Wii U Stream — PC 480p Turbo")
        self.root.geometry("1000x650")
        self.root.minsize(640, 410)
        self.root.configure(bg=BACKGROUND)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.frame_queue: queue.Queue[DecodedFrame] = queue.Queue(maxsize=1)
        self.state_queue: queue.Queue[tuple[str, bool]] = queue.Queue()
        self.receiver = StreamReceiver(self.frame_queue, self._queue_state)
        self.connected = False
        self.fullscreen = False
        self.current_image: Image.Image | None = None
        self.tk_image: ImageTk.PhotoImage | None = None
        self.tk_image_size: tuple[int, int] | None = None
        self.resize_job: str | None = None

        self.ip_var = tk.StringVar(value=load_ip())
        self.status_var = tk.StringVar(value="Déconnecté")
        self.stats_var = tk.StringVar(value="Réception 0.0 FPS • affichage 0.0 FPS • 0.00 Mbit/s")
        self.info_var = tk.StringVar(value="F11 ou double-clic : plein écran")

        self._configure_styles()
        self._build_ui()
        self._bind_keys()
        self.root.after(8, self._poll)

    def _configure_styles(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Title.TLabel", background=PANEL, foreground=TEXT, font=("Segoe UI", 15, "bold"))
        style.configure("Body.TLabel", background=PANEL, foreground=SECONDARY, font=("Segoe UI", 10))
        style.configure("Status.TLabel", background=PANEL, foreground=SECONDARY, font=("Segoe UI", 9))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 7))
        style.configure("TEntry", padding=7)

    def _build_ui(self) -> None:
        self.toolbar = ttk.Frame(self.root, style="Panel.TFrame", padding=(14, 10))
        self.toolbar.pack(side=tk.TOP, fill=tk.X)

        ttk.Label(self.toolbar, text="Wii U Stream 480p Turbo", style="Title.TLabel").grid(
            row=0, column=0, rowspan=2, sticky="w", padx=(0, 18)
        )
        ttk.Label(self.toolbar, text="IP de la Wii U", style="Body.TLabel").grid(row=0, column=1, sticky="w")
        self.ip_entry = ttk.Entry(self.toolbar, textvariable=self.ip_var, width=18)
        self.ip_entry.grid(row=1, column=1, sticky="ew", padx=(0, 10), pady=(3, 0))
        self.ip_entry.bind("<Return>", lambda _event: self.toggle_connection())

        self.connect_button = ttk.Button(
            self.toolbar, text="Connexion", command=self.toggle_connection, style="Accent.TButton"
        )
        self.connect_button.grid(row=1, column=2, padx=(0, 10), pady=(3, 0))
        self.fullscreen_button = ttk.Button(self.toolbar, text="Plein écran", command=self.toggle_fullscreen)
        self.fullscreen_button.grid(row=1, column=3, pady=(3, 0))

        self.status_label = ttk.Label(self.toolbar, textvariable=self.status_var, style="Status.TLabel")
        self.status_label.grid(row=2, column=1, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(self.toolbar, textvariable=self.stats_var, style="Status.TLabel").grid(
            row=3, column=1, columnspan=3, sticky="w", pady=(1, 0)
        )
        self.toolbar.columnconfigure(1, weight=1)

        self.canvas = tk.Canvas(self.root, bg="#05070a", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Double-Button-1>", lambda _event: self.toggle_fullscreen())
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.stream_item = self.canvas.create_image(0, 0, anchor=tk.CENTER, state="hidden")
        self.placeholder = self.canvas.create_text(
            0,
            0,
            text="Entre l’adresse IP de la Wii U puis clique sur Connexion",
            fill=SECONDARY,
            font=("Segoe UI", 14),
            justify=tk.CENTER,
        )

        self.footer = tk.Label(
            self.root,
            textvariable=self.info_var,
            bg=BACKGROUND,
            fg=SECONDARY,
            font=("Segoe UI", 9),
            anchor="w",
            padx=12,
            pady=4,
        )
        self.footer.pack(side=tk.BOTTOM, fill=tk.X)
        self.root.after_idle(self._center_placeholder)

    def _bind_keys(self) -> None:
        self.root.bind("<F11>", lambda _event: self.toggle_fullscreen())
        self.root.bind("<Alt-Return>", lambda _event: self.toggle_fullscreen())
        self.root.bind("<Escape>", lambda _event: self.exit_fullscreen())

    def toggle_connection(self) -> None:
        self.disconnect() if self.connected else self.connect()

    def connect(self) -> None:
        try:
            ip = validate_ipv4(self.ip_var.get())
        except ValueError as exc:
            messagebox.showerror("Adresse invalide", str(exc), parent=self.root)
            return
        try:
            save_ip(ip)
        except OSError:
            pass
        self.connected = True
        self.ip_entry.configure(state="disabled")
        self.connect_button.configure(text="Déconnexion")
        self.status_var.set(f"Connexion à {ip}…")
        self.receiver.start(ip)

    def disconnect(self) -> None:
        self.connected = False
        self.receiver.stop()
        self.ip_entry.configure(state="normal")
        self.connect_button.configure(text="Connexion")
        self.status_var.set("Déconnecté")
        self.stats_var.set("Réception 0.0 FPS • affichage 0.0 FPS • 0.00 Mbit/s")
        self._clear_image()

    def _queue_state(self, message: str, is_error: bool) -> None:
        self.state_queue.put((message, is_error))

    def _poll(self) -> None:
        while True:
            try:
                message, is_error = self.state_queue.get_nowait()
            except queue.Empty:
                break
            self.status_var.set(message)
            self.status_label.configure(foreground=ERROR if is_error else SECONDARY)
            if is_error:
                self.connected = False
                self.ip_entry.configure(state="normal")
                self.connect_button.configure(text="Connexion")

        latest: DecodedFrame | None = None
        while True:
            try:
                candidate = self.frame_queue.get_nowait()
            except queue.Empty:
                break
            if latest is not None:
                latest.image.close()
            latest = candidate
        if latest is not None:
            self._show_frame(latest)

        stats = self.receiver.stats()
        state = "aucune image"
        if stats.milliseconds_since_last_frame is not None:
            state = "actif" if stats.milliseconds_since_last_frame <= 1500 else "interrompu"
        self.stats_var.set(
            f"Réception {stats.receive_fps:.1f} FPS • affichage {stats.display_fps:.1f} FPS • "
            f"{stats.megabits_per_second:.2f} Mbit/s • pertes {stats.dropped_frames} • "
            f"retard évité {stats.skipped_for_latency} • {state}"
        )
        self.root.after(8, self._poll)

    def _show_frame(self, frame: DecodedFrame) -> None:
        if self.current_image is not None:
            self.current_image.close()
        self.current_image = frame.image
        source = "TV" if frame.stream == 1 else "GamePad"
        self.status_var.set(
            f"{source} • {frame.width}×{frame.height} • JPEG {frame.jpeg_quality}% • "
            f"{frame.jpeg_bytes / 1024.0:.1f} Kio"
        )
        self.status_label.configure(foreground=SECONDARY)
        self.info_var.set(f"Image {frame.frame_id} • protocole v2 • F11 : plein écran")
        self._render_current_image()

    def _render_current_image(self) -> None:
        image = self.current_image
        if image is None:
            self._center_placeholder()
            return
        canvas_width = max(1, self.canvas.winfo_width())
        canvas_height = max(1, self.canvas.winfo_height())
        ratio = min(canvas_width / image.width, canvas_height / image.height)
        target = (max(1, int(image.width * ratio)), max(1, int(image.height * ratio)))

        display_image = image
        temporary = False
        if target != image.size:
            display_image = image.resize(target, Image.Resampling.NEAREST)
            temporary = True

        if self.tk_image is not None and self.tk_image_size == target:
            self.tk_image.paste(display_image)
        else:
            self.tk_image = ImageTk.PhotoImage(display_image)
            self.tk_image_size = target
            self.canvas.itemconfigure(self.stream_item, image=self.tk_image)

        if temporary:
            display_image.close()
        self.canvas.itemconfigure(self.placeholder, state="hidden")
        self.canvas.coords(self.stream_item, canvas_width // 2, canvas_height // 2)
        self.canvas.itemconfigure(self.stream_item, state="normal")

    def _on_canvas_resize(self, _event: tk.Event) -> None:
        if self.resize_job is not None:
            self.root.after_cancel(self.resize_job)
        self.resize_job = self.root.after(35, self._render_current_image)

    def _center_placeholder(self) -> None:
        self.canvas.coords(
            self.placeholder,
            self.canvas.winfo_width() // 2,
            self.canvas.winfo_height() // 2,
        )

    def _clear_image(self) -> None:
        if self.current_image is not None:
            self.current_image.close()
            self.current_image = None
        self.tk_image = None
        self.tk_image_size = None
        self.canvas.itemconfigure(self.stream_item, image="", state="hidden")
        self.canvas.itemconfigure(self.placeholder, state="normal")
        self._center_placeholder()

    def toggle_fullscreen(self) -> None:
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)
        self.toolbar.pack_forget() if self.fullscreen else self.toolbar.pack(side=tk.TOP, fill=tk.X, before=self.canvas)
        self.footer.pack_forget() if self.fullscreen else self.footer.pack(side=tk.BOTTOM, fill=tk.X)
        self.root.after(50, self._render_current_image)

    def exit_fullscreen(self) -> None:
        if self.fullscreen:
            self.toggle_fullscreen()

    def close(self) -> None:
        self.receiver.stop()
        self._clear_image()
        self.root.destroy()
