from __future__ import annotations

import io
import queue
import socket
import threading
import time
from dataclasses import dataclass
from typing import Callable

from PIL import Image, UnidentifiedImageError

from .assembler import EncodedFrame, FrameAssembler, JpegBufferPool
from .protocol import (
    CONTROL_PORT,
    DEFAULT_VIDEO_PORT,
    MAX_DATAGRAM_SIZE,
    hello_packet,
    parse_video_header,
    validate_ipv4,
)


@dataclass(slots=True)
class DecodedFrame:
    image: Image.Image
    stream: int
    frame_id: int
    width: int
    height: int
    jpeg_quality: int
    jpeg_bytes: int


@dataclass(frozen=True, slots=True)
class StreamStats:
    receive_fps: float
    display_fps: float
    megabits_per_second: float
    dropped_frames: int
    skipped_for_latency: int
    milliseconds_since_last_frame: int | None


StateCallback = Callable[[str, bool], None]


class StreamReceiver:
    """Protocol-v2 UDP receiver optimized for the newest 854x480 frame."""

    def __init__(
        self,
        frame_queue: queue.Queue[DecodedFrame],
        state_callback: StateCallback,
        video_port: int = DEFAULT_VIDEO_PORT,
    ) -> None:
        self._frame_queue = frame_queue
        self._encoded_queue: queue.Queue[EncodedFrame] = queue.Queue(maxsize=1)
        self._state_callback = state_callback
        self._video_port = video_port
        self._stop_event = threading.Event()
        self._network_thread: threading.Thread | None = None
        self._decoder_thread: threading.Thread | None = None
        self._socket: socket.socket | None = None
        self._pool = JpegBufferPool()
        self._stats_lock = threading.Lock()
        self._stats = StreamStats(0.0, 0.0, 0.0, 0, 0, None)
        self._latency_skips = 0
        self._decode_errors = 0
        self._decoded_window = 0
        self._last_decoded_at: float | None = None

    @property
    def running(self) -> bool:
        return self._network_thread is not None and self._network_thread.is_alive()

    def start(self, ip_address: str) -> None:
        if self.running:
            return
        ip = validate_ipv4(ip_address)
        self._stop_event.clear()
        self._latency_skips = 0
        self._decode_errors = 0
        self._decoded_window = 0
        self._last_decoded_at = None
        self._clear_encoded_queue()
        self._clear_frame_queue()
        self._network_thread = threading.Thread(
            target=self._run_network,
            args=(ip,),
            name="WiiUStreamNetwork",
            daemon=True,
        )
        self._decoder_thread = threading.Thread(
            target=self._run_decoder,
            name="WiiUStreamDecoder",
            daemon=True,
        )
        self._decoder_thread.start()
        self._network_thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        sock = self._socket
        self._socket = None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

        for thread in (self._network_thread, self._decoder_thread):
            if thread is not None and thread is not threading.current_thread():
                thread.join(timeout=1.0)
        self._network_thread = None
        self._decoder_thread = None
        self._clear_encoded_queue()
        self._pool.clear()

    def stats(self) -> StreamStats:
        with self._stats_lock:
            stats = self._stats
        if self._last_decoded_at is None:
            since_ms = None
        else:
            since_ms = max(0, int((time.monotonic() - self._last_decoded_at) * 1000))
        return StreamStats(
            receive_fps=stats.receive_fps,
            display_fps=stats.display_fps,
            megabits_per_second=stats.megabits_per_second,
            dropped_frames=stats.dropped_frames,
            skipped_for_latency=stats.skipped_for_latency,
            milliseconds_since_last_frame=since_ms,
        )

    def _run_network(self, ip_address: str) -> None:
        assembler = FrameAssembler(self._pool)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._socket = sock
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            # A deliberately small queue prevents Windows from preserving old video.
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 192 * 1024)
            sock.settimeout(0.025)
            sock.bind(("0.0.0.0", self._video_port))
        except OSError as exc:
            self._state_callback(
                f"Impossible d’ouvrir le port UDP {self._video_port} : {exc}", True
            )
            try:
                sock.close()
            except OSError:
                pass
            return

        self._state_callback(f"Connecté à {ip_address} — attente du flux v2…", False)
        target = (ip_address, CONTROL_PORT)
        hello = hello_packet(self._video_port)
        packet_buffer = bytearray(MAX_DATAGRAM_SIZE)
        packet_view = memoryview(packet_buffer)
        next_heartbeat = 0.0
        window_start = time.monotonic()
        completed_window = 0
        bytes_window = 0
        previous_frame_id: dict[int, int] = {}
        sequence_drops = 0

        try:
            while not self._stop_event.is_set():
                now = time.monotonic()
                if now >= next_heartbeat:
                    try:
                        sock.sendto(hello, target)
                    except OSError as exc:
                        if not self._stop_event.is_set():
                            self._state_callback(f"Erreur d’envoi vers la Wii U : {exc}", True)
                        break
                    next_heartbeat = now + 1.0

                try:
                    packet_length, source = sock.recvfrom_into(packet_buffer)
                except socket.timeout:
                    assembler.cleanup_expired()
                    self._maybe_publish_stats(
                        window_start,
                        completed_window,
                        bytes_window,
                        sequence_drops,
                        assembler,
                    )
                    continue
                except OSError as exc:
                    if not self._stop_event.is_set():
                        self._state_callback(f"Erreur réseau : {exc}", True)
                    break

                if source[0] != ip_address:
                    continue

                header = parse_video_header(packet_buffer, packet_length)
                if header is None:
                    continue
                completed = assembler.accept(header, packet_view[:packet_length])
                if completed is None:
                    continue

                previous = previous_frame_id.get(completed.stream)
                if previous is not None:
                    gap = (completed.frame_id - previous) & 0xFFFFFFFF
                    if 1 < gap < 0x80000000:
                        sequence_drops += gap - 1
                previous_frame_id[completed.stream] = completed.frame_id

                completed_window += 1
                bytes_window += completed.jpeg_size
                self._publish_latest_encoded(completed)

                now = time.monotonic()
                if now - window_start >= 1.0:
                    self._publish_stats(
                        now - window_start,
                        completed_window,
                        bytes_window,
                        sequence_drops,
                        assembler,
                    )
                    window_start = now
                    completed_window = 0
                    bytes_window = 0
                    self._decoded_window = 0
        finally:
            assembler.clear()
            try:
                sock.close()
            except OSError:
                pass
            if self._socket is sock:
                self._socket = None

    def _run_decoder(self) -> None:
        while not self._stop_event.is_set():
            try:
                encoded = self._encoded_queue.get(timeout=0.05)
            except queue.Empty:
                continue

            while True:
                try:
                    newer = self._encoded_queue.get_nowait()
                except queue.Empty:
                    break
                self._pool.release(encoded.jpeg)
                encoded = newer
                self._latency_skips += 1

            try:
                # The copy is bounded by the compressed JPEG size, normally only
                # a few tens of KiB at quality 24–48. It releases the pooled buffer
                # immediately and keeps the decoder independent from the network.
                jpeg_bytes = bytes(memoryview(encoded.jpeg)[: encoded.jpeg_size])
                with Image.open(io.BytesIO(jpeg_bytes), formats=("JPEG",)) as source_image:
                    source_image.load()
                    image = source_image.copy() if source_image.mode == "RGB" else source_image.convert("RGB")
            except (UnidentifiedImageError, OSError, ValueError):
                self._decode_errors += 1
                self._pool.release(encoded.jpeg)
                continue

            self._pool.release(encoded.jpeg)
            self._decoded_window += 1
            self._last_decoded_at = time.monotonic()
            self._publish_latest_decoded(
                DecodedFrame(
                    image=image,
                    stream=encoded.stream,
                    frame_id=encoded.frame_id,
                    width=encoded.width,
                    height=encoded.height,
                    jpeg_quality=encoded.jpeg_quality,
                    jpeg_bytes=encoded.jpeg_size,
                )
            )

    def _publish_latest_encoded(self, frame: EncodedFrame) -> None:
        try:
            old = self._encoded_queue.get_nowait()
            self._pool.release(old.jpeg)
            self._latency_skips += 1
        except queue.Empty:
            pass
        try:
            self._encoded_queue.put_nowait(frame)
        except queue.Full:
            self._pool.release(frame.jpeg)
            self._latency_skips += 1

    def _publish_latest_decoded(self, frame: DecodedFrame) -> None:
        while True:
            try:
                old = self._frame_queue.get_nowait()
                old.image.close()
                self._latency_skips += 1
            except queue.Empty:
                break
        try:
            self._frame_queue.put_nowait(frame)
        except queue.Full:
            frame.image.close()
            self._latency_skips += 1

    def _clear_encoded_queue(self) -> None:
        while True:
            try:
                frame = self._encoded_queue.get_nowait()
                self._pool.release(frame.jpeg)
            except queue.Empty:
                return

    def _clear_frame_queue(self) -> None:
        while True:
            try:
                frame = self._frame_queue.get_nowait()
                frame.image.close()
            except queue.Empty:
                return

    def _maybe_publish_stats(
        self,
        window_start: float,
        completed_frames: int,
        jpeg_bytes: int,
        sequence_drops: int,
        assembler: FrameAssembler,
    ) -> None:
        elapsed = time.monotonic() - window_start
        if elapsed >= 1.0:
            self._publish_stats(
                elapsed,
                completed_frames,
                jpeg_bytes,
                sequence_drops,
                assembler,
            )

    def _publish_stats(
        self,
        elapsed: float,
        completed_frames: int,
        jpeg_bytes: int,
        sequence_drops: int,
        assembler: FrameAssembler,
    ) -> None:
        safe_elapsed = max(elapsed, 0.001)
        with self._stats_lock:
            self._stats = StreamStats(
                receive_fps=completed_frames / safe_elapsed,
                display_fps=self._decoded_window / safe_elapsed,
                megabits_per_second=(jpeg_bytes * 8.0 / 1_000_000.0) / safe_elapsed,
                dropped_frames=(
                    sequence_drops
                    + assembler.timed_out_frames
                    + assembler.invalid_frames
                    + assembler.stale_frames
                    + self._decode_errors
                ),
                skipped_for_latency=self._latency_skips,
                milliseconds_since_last_frame=None,
            )
