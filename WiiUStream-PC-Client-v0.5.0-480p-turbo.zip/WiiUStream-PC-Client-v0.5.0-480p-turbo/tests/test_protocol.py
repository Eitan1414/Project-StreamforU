from __future__ import annotations

import random
import struct
import unittest

from wiiu_stream.assembler import FrameAssembler, JpegBufferPool
from wiiu_stream.protocol import (
    CONTROL_MAGIC,
    FLAG_NO_FRAME_CRC,
    HELLO_TYPE,
    VERSION,
    VIDEO_HEADER_SIZE,
    VIDEO_MAGIC,
    VIDEO_PAYLOAD_SIZE,
    hello_packet,
    parse_video_header,
    validate_ipv4,
)


class ProtocolV2Tests(unittest.TestCase):
    def test_hello_packet(self) -> None:
        self.assertEqual(
            struct.unpack(">IBBHI", hello_packet(9445)),
            (CONTROL_MAGIC, VERSION, HELLO_TYPE, 9445, 0),
        )

    def test_ipv4_validation(self) -> None:
        self.assertEqual(validate_ipv4(" 192.168.1.10 "), "192.168.1.10")
        with self.assertRaises(ValueError):
            validate_ipv4("300.1.1.1")

    def test_out_of_order_reassembly_without_crc(self) -> None:
        jpeg = b"\xff\xd8" + bytes(range(256)) * 55 + b"\xff\xd9"
        chunks = [jpeg[index:index + VIDEO_PAYLOAD_SIZE] for index in range(0, len(jpeg), VIDEO_PAYLOAD_SIZE)]
        packets: list[bytes] = []
        for index, payload in enumerate(chunks):
            header = struct.pack(
                ">IBBBBIIIHHHHHBB",
                VIDEO_MAGIC,
                VERSION,
                0,
                FLAG_NO_FRAME_CRC,
                VIDEO_HEADER_SIZE,
                42,
                len(jpeg),
                0,
                index,
                len(chunks),
                len(payload),
                854,
                480,
                34,
                0,
            )
            packets.append(header + payload)

        random.Random(123).shuffle(packets)
        pool = JpegBufferPool()
        assembler = FrameAssembler(pool)
        completed = None
        for packet in packets:
            header = parse_video_header(packet, len(packet))
            self.assertIsNotNone(header)
            assert header is not None
            completed = assembler.accept(header, packet) or completed

        self.assertIsNotNone(completed)
        assert completed is not None
        self.assertEqual(bytes(completed.jpeg[: completed.jpeg_size]), jpeg)
        pool.release(completed.jpeg)

    def test_v1_packet_is_rejected(self) -> None:
        payload = b"x" * 20
        packet = struct.pack(
            ">IBBBBIIIHHHHHBB",
            VIDEO_MAGIC,
            1,
            0,
            0,
            VIDEO_HEADER_SIZE,
            1,
            len(payload),
            123,
            0,
            1,
            len(payload),
            854,
            480,
            34,
            0,
        ) + payload
        self.assertIsNone(parse_video_header(packet, len(packet)))


if __name__ == "__main__":
    unittest.main()
