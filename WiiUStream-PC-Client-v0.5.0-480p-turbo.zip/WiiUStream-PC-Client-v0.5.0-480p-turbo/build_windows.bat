@echo off
setlocal
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
python -m unittest discover -s tests -v
python -m PyInstaller --noconfirm --clean --onefile --windowed --name WiiUStream-PC-480p-Turbo --icon assets\wiiustream.ico --hidden-import PIL._tkinter_finder main.py
if errorlevel 1 exit /b 1
echo.
echo EXE cree dans dist\WiiUStream-PC-480p-Turbo.exe
endlocal
