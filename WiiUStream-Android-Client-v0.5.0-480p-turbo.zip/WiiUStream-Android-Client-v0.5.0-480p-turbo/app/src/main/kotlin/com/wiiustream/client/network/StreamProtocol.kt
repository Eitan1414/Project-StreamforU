package com.wiiustream.client.network

import java.net.InetAddress

internal object StreamProtocol {
    const val CONTROL_MAGIC: Int = 0x57555343 // WUSC
    const val VIDEO_MAGIC: Int = 0x57555356 // WUSV
    const val VERSION: Int = 2
    const val HELLO_TYPE: Int = 1
    const val CONTROL_PORT: Int = 9444
    const val DEFAULT_VIDEO_PORT: Int = 9445
    const val CONTROL_PACKET_SIZE: Int = 12
    const val VIDEO_HEADER_SIZE: Int = 32
    const val FLAG_NO_FRAME_CRC: Int = 1

    const val VIDEO_PAYLOAD_SIZE: Int = 1440
    const val MAX_DATAGRAM_SIZE: Int = VIDEO_HEADER_SIZE + VIDEO_PAYLOAD_SIZE
    const val MAX_FRAME_SIZE: Int = 512 * 1024
    const val MAX_CHUNK_COUNT: Int = 512
    const val FRAME_TIMEOUT_NS: Long = 120_000_000L

    fun helloPacket(videoPort: Int): ByteArray {
        val result = ByteArray(CONTROL_PACKET_SIZE)
        writeU32(result, 0, CONTROL_MAGIC.toLong())
        result[4] = VERSION.toByte()
        result[5] = HELLO_TYPE.toByte()
        writeU16(result, 6, videoPort)
        writeU32(result, 8, 0)
        return result
    }

    /** Parses the header without allocating ByteBuffer objects for every UDP packet. */
    fun parseVideoHeader(data: ByteArray, packetLength: Int): VideoHeader? {
        if (packetLength < VIDEO_HEADER_SIZE || packetLength > MAX_DATAGRAM_SIZE) return null

        val magic = readU32(data, 0).toInt()
        val version = u8(data[4])
        val stream = u8(data[5])
        val flags = u8(data[6])
        val headerSize = u8(data[7])
        val frameId = readU32(data, 8)
        val frameSize = readU32(data, 12).toInt()
        val frameCrc32 = readU32(data, 16)
        val chunkIndex = readU16(data, 20)
        val chunkCount = readU16(data, 22)
        val payloadSize = readU16(data, 24)
        val width = readU16(data, 26)
        val height = readU16(data, 28)
        val jpegQuality = u8(data[30])
        val reserved = u8(data[31])

        if (magic != VIDEO_MAGIC || version != VERSION || headerSize != VIDEO_HEADER_SIZE) return null
        if (stream !in 0..1 || flags and FLAG_NO_FRAME_CRC == 0 || flags and FLAG_NO_FRAME_CRC.inv() != 0) return null
        if (reserved != 0 || frameCrc32 != 0L) return null
        if (frameSize !in 1..MAX_FRAME_SIZE) return null
        if (chunkCount !in 1..MAX_CHUNK_COUNT || chunkIndex >= chunkCount) return null
        if (payloadSize !in 1..VIDEO_PAYLOAD_SIZE) return null
        if (payloadSize > packetLength - VIDEO_HEADER_SIZE) return null
        if (width != 854 || height != 480 || jpegQuality !in 20..55) return null

        val expectedChunkCount = (frameSize + VIDEO_PAYLOAD_SIZE - 1) / VIDEO_PAYLOAD_SIZE
        if (chunkCount != expectedChunkCount) return null

        val offset = chunkIndex * VIDEO_PAYLOAD_SIZE
        val expectedPayloadSize = minOf(VIDEO_PAYLOAD_SIZE, frameSize - offset)
        if (offset < 0 || expectedPayloadSize <= 0 || payloadSize != expectedPayloadSize) return null

        return VideoHeader(
            stream = stream,
            frameId = frameId,
            frameSize = frameSize,
            chunkIndex = chunkIndex,
            chunkCount = chunkCount,
            payloadSize = payloadSize,
            width = width,
            height = height,
            jpegQuality = jpegQuality
        )
    }

    fun isNewerFrame(candidate: Long, reference: Long): Boolean {
        val distance = (candidate - reference) and 0xFFFF_FFFFL
        return distance in 1L..0x7FFF_FFFFL
    }

    fun isValidIpv4(value: String): Boolean {
        val parts = value.trim().split('.')
        if (parts.size != 4) return false
        return parts.all { part ->
            part.isNotEmpty() && part.length <= 3 && part.all(Char::isDigit) &&
                part.toIntOrNull() in 0..255
        }
    }

    fun resolveIpv4(value: String): InetAddress = InetAddress.getByName(value.trim())

    private fun u8(value: Byte): Int = value.toInt() and 0xFF

    private fun readU16(data: ByteArray, offset: Int): Int =
        (u8(data[offset]) shl 8) or u8(data[offset + 1])

    private fun readU32(data: ByteArray, offset: Int): Long =
        ((u8(data[offset]).toLong() shl 24) or
            (u8(data[offset + 1]).toLong() shl 16) or
            (u8(data[offset + 2]).toLong() shl 8) or
            u8(data[offset + 3]).toLong()) and 0xFFFF_FFFFL

    private fun writeU16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value ushr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun writeU32(data: ByteArray, offset: Int, value: Long) {
        data[offset] = (value ushr 24).toByte()
        data[offset + 1] = (value ushr 16).toByte()
        data[offset + 2] = (value ushr 8).toByte()
        data[offset + 3] = value.toByte()
    }
}

internal data class VideoHeader(
    val stream: Int,
    val frameId: Long,
    val frameSize: Int,
    val chunkIndex: Int,
    val chunkCount: Int,
    val payloadSize: Int,
    val width: Int,
    val height: Int,
    val jpegQuality: Int
)
