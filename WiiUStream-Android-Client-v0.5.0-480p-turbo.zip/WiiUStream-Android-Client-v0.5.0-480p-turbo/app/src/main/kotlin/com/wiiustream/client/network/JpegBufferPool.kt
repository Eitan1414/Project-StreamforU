package com.wiiustream.client.network

import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

internal class JpegBufferPool {
    private val buffers = ConcurrentLinkedQueue<ByteArray>()
    private val pooledCount = AtomicInteger(0)

    fun acquire(): ByteArray {
        val existing = buffers.poll()
        if (existing != null) {
            pooledCount.decrementAndGet()
            return existing
        }
        return ByteArray(StreamProtocol.MAX_FRAME_SIZE)
    }

    fun release(buffer: ByteArray?) {
        if (buffer == null || buffer.size != StreamProtocol.MAX_FRAME_SIZE) return
        while (true) {
            val count = pooledCount.get()
            if (count >= MAX_POOLED_BUFFERS) return
            if (pooledCount.compareAndSet(count, count + 1)) {
                buffers.offer(buffer)
                return
            }
        }
    }

    fun clear() {
        buffers.clear()
        pooledCount.set(0)
    }

    companion object {
        private const val MAX_POOLED_BUFFERS = 4
    }
}
