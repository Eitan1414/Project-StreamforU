package com.wiiustream.client.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Stable UI-thread renderer with bitmap recycling supplied by StreamReceiver.
 * postInvalidateOnAnimation coalesces redraws to the display refresh cycle.
 */
internal class StreamView(context: Context) : View(context) {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val frameLock = Any()

    var bitmapRecycler: ((Bitmap) -> Unit)? = null

    private var pendingBitmap: Bitmap? = null
    private var displayedBitmap: Bitmap? = null

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun renderFrame(bitmap: Bitmap): Boolean {
        if (bitmap.isRecycled) return false
        var replaced: Bitmap? = null
        synchronized(frameLock) {
            replaced = pendingBitmap
            pendingBitmap = bitmap
        }
        replaced?.let(::releaseBitmap)
        postInvalidateOnAnimation()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        var previous: Bitmap? = null
        val frame: Bitmap? = synchronized(frameLock) {
            pendingBitmap?.let { newest ->
                previous = displayedBitmap
                displayedBitmap = newest
                pendingBitmap = null
            }
            displayedBitmap
        }

        if (frame != null && !frame.isRecycled && width > 0 && height > 0) {
            canvas.drawBitmap(frame, null, destination(frame, width, height), paint)
        }

        previous?.let { old ->
            if (old !== frame) releaseBitmap(old)
        }
    }

    fun clearFrame() {
        val frames = synchronized(frameLock) {
            val values = listOfNotNull(pendingBitmap, displayedBitmap)
                .distinctBy { System.identityHashCode(it) }
            pendingBitmap = null
            displayedBitmap = null
            values
        }
        frames.forEach(::releaseBitmap)
        postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        clearFrame()
        super.onDetachedFromWindow()
    }

    private fun releaseBitmap(bitmap: Bitmap) {
        if (bitmap.isRecycled) return
        val recycler = bitmapRecycler
        if (recycler != null) recycler(bitmap) else bitmap.recycle()
    }

    private fun destination(bitmap: Bitmap, viewWidth: Int, viewHeight: Int): RectF {
        if (viewWidth <= 0 || viewHeight <= 0 || bitmap.height <= 0) return RectF()
        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewRatio = viewWidth.toFloat() / viewHeight.toFloat()
        return if (sourceRatio > viewRatio) {
            val scaledHeight = viewWidth / sourceRatio
            val top = (viewHeight - scaledHeight) / 2f
            RectF(0f, top, viewWidth.toFloat(), top + scaledHeight)
        } else {
            val scaledWidth = viewHeight * sourceRatio
            val left = (viewWidth - scaledWidth) / 2f
            RectF(left, 0f, left + scaledWidth, viewHeight.toFloat())
        }
    }
}
