package com.wiiustream.client.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

internal class StreamReceiver(
    private val listener: Listener,
    private val videoPort: Int = StreamProtocol.DEFAULT_VIDEO_PORT
) {
    interface Listener {
        fun onState(message: String, isError: Boolean = false)
        fun onFrame(frame: DecodedFrame)
        fun onStats(stats: StreamStats)
    }

    private val running = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val sessionCounter = AtomicLong(0)
    private val socketRef = AtomicReference<DatagramSocket?>()
    private val jpegPool = JpegBufferPool()
    private val latestEncoded = AtomicReference<EncodedFrame?>()
    private val decodeSignal = Semaphore(0)
    private val executor = Executors.newFixedThreadPool(3) { task ->
        Thread(task, "WiiUStream-Turbo").apply { isDaemon = true }
    }

    private val bitmapPool = ConcurrentLinkedQueue<Bitmap>()
    private val pooledBitmapCount = AtomicInteger(0)
    private val latencySkips = AtomicLong(0)
    private val decodeErrors = AtomicLong(0)
    private val decodedSinceStats = AtomicLong(0)
    private val lastDecodedAt = AtomicLong(0)
    private val lastCompletedFrame = AtomicLong(-1)

    fun start(ipAddress: String) {
        if (closed.get() || !running.compareAndSet(false, true)) return
        val sessionId = sessionCounter.incrementAndGet()
        resetCounters()
        try {
            executor.execute { runNetworkSession(sessionId, ipAddress) }
        } catch (error: Throwable) {
            running.set(false)
            notifyState("Impossible de démarrer : ${error.safeMessage()}", true)
        }
    }

    private fun runNetworkSession(sessionId: Long, ipAddress: String) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_MORE_FAVORABLE)
        var socket: DatagramSocket? = null
        val assembler = FrameAssembler(jpegPool)
        try {
            val address = StreamProtocol.resolveIpv4(ipAddress)
            socket = DatagramSocket(null).apply {
                reuseAddress = true
                soTimeout = 25
                bind(InetSocketAddress("0.0.0.0", videoPort))
                try { receiveBufferSize = 192 * 1024 } catch (_: Throwable) {}
            }
            socketRef.set(socket)
            notifyState("Connecté à ${address.hostAddress} — attente du flux turbo…", false)

            executor.execute { guardedLoop("heartbeat") { heartbeatLoop(sessionId, socket, address) } }
            executor.execute { guardedLoop("decoder") { decodeLoop(sessionId) } }
            receiveLoop(sessionId, socket, address, assembler)
        } catch (error: Throwable) {
            if (isSessionActive(sessionId)) notifyState("Erreur réseau : ${error.safeMessage()}", true)
        } finally {
            assembler.clear()
            try { socket?.close() } catch (_: Throwable) {}
            socketRef.compareAndSet(socket, null)
            releaseEncoded(latestEncoded.getAndSet(null))
            decodeSignal.release()
            if (sessionCounter.get() == sessionId) running.set(false)
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        sessionCounter.incrementAndGet()
        try { socketRef.getAndSet(null)?.close() } catch (_: Throwable) {}
        releaseEncoded(latestEncoded.getAndSet(null))
        decodeSignal.release()
        notifyState("Déconnecté", false)
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        stop()
        executor.shutdownNow()
        try { executor.awaitTermination(300, TimeUnit.MILLISECONDS) }
        catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        clearBitmapPool()
        jpegPool.clear()
    }

    fun recycleBitmap(bitmap: Bitmap) {
        if (bitmap.isRecycled) return
        if (closed.get() || !bitmap.isMutable || bitmap.width != 854 || bitmap.height != 480) {
            bitmap.recycle()
            return
        }
        while (true) {
            val count = pooledBitmapCount.get()
            if (count >= 3) {
                bitmap.recycle()
                return
            }
            if (pooledBitmapCount.compareAndSet(count, count + 1)) {
                bitmapPool.offer(bitmap)
                return
            }
        }
    }

    private fun acquireBitmap(): Bitmap? {
        val bitmap = bitmapPool.poll() ?: return null
        pooledBitmapCount.decrementAndGet()
        return if (!bitmap.isRecycled) bitmap else null
    }

    private fun clearBitmapPool() {
        while (true) {
            val bitmap = bitmapPool.poll() ?: break
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        pooledBitmapCount.set(0)
    }

    private fun guardedLoop(name: String, block: () -> Unit) {
        try { block() }
        catch (error: Throwable) {
            if (!closed.get()) notifyState("Erreur $name : ${error.safeMessage()}", true)
        }
    }

    private fun resetCounters() {
        releaseEncoded(latestEncoded.getAndSet(null))
        decodeSignal.drainPermits()
        latencySkips.set(0)
        decodeErrors.set(0)
        decodedSinceStats.set(0)
        lastDecodedAt.set(0)
        lastCompletedFrame.set(-1)
    }

    private fun isSessionActive(sessionId: Long): Boolean =
        running.get() && !closed.get() && sessionCounter.get() == sessionId

    private fun heartbeatLoop(sessionId: Long, socket: DatagramSocket, address: InetAddress) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_BACKGROUND)
        val payload = StreamProtocol.helloPacket(videoPort)
        val packet = DatagramPacket(payload, payload.size, address, StreamProtocol.CONTROL_PORT)
        while (isSessionActive(sessionId) && !socket.isClosed) {
            try { socket.send(packet) }
            catch (error: SocketException) {
                if (isSessionActive(sessionId)) notifyState("Connexion interrompue", true)
                break
            } catch (error: Throwable) {
                if (isSessionActive(sessionId)) notifyState("Signal impossible : ${error.safeMessage()}", true)
            }
            try { Thread.sleep(1_000) }
            catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
        }
    }

    private fun receiveLoop(
        sessionId: Long,
        socket: DatagramSocket,
        expectedAddress: InetAddress,
        assembler: FrameAssembler
    ) {
        val buffer = ByteArray(StreamProtocol.MAX_DATAGRAM_SIZE)
        val packet = DatagramPacket(buffer, buffer.size)
        var totalBytes = 0L
        var windowCompleted = 0L
        var windowBytes = 0L
        var windowStart = SystemClock.elapsedRealtime()
        var sequenceDrops = 0L

        while (isSessionActive(sessionId) && !socket.isClosed) {
            packet.length = buffer.size
            try { socket.receive(packet) }
            catch (_: SocketTimeoutException) {
                assembler.cleanupExpired()
                val now = SystemClock.elapsedRealtime()
                if (now - windowStart >= 1_000) {
                    publishStats(now, windowStart, windowCompleted, windowBytes, assembler, sequenceDrops, totalBytes)
                    windowStart = now; windowCompleted = 0; windowBytes = 0
                }
                continue
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) notifyState("Socket fermée : ${error.safeMessage()}", true)
                break
            } catch (error: Throwable) {
                if (isSessionActive(sessionId)) notifyState("Réception impossible : ${error.safeMessage()}", true)
                break
            }

            if (packet.address != expectedAddress) continue
            val packetLength = packet.length
            totalBytes += packetLength
            val header = StreamProtocol.parseVideoHeader(buffer, packetLength) ?: continue
            val completed = try { assembler.accept(header, buffer) }
            catch (error: OutOfMemoryError) {
                decodeErrors.incrementAndGet(); notifyState("Mémoire insuffisante", true); null
            } ?: continue

            val previous = lastCompletedFrame.getAndSet(completed.frameId)
            if (previous >= 0) {
                val gap = (completed.frameId - previous) and 0xFFFF_FFFFL
                if (gap in 2L..0x7FFF_FFFFL) sequenceDrops += gap - 1
            }
            windowCompleted++
            windowBytes += completed.jpegSize
            publishLatestEncoded(completed)

            val now = SystemClock.elapsedRealtime()
            if (now - windowStart >= 1_000) {
                publishStats(now, windowStart, windowCompleted, windowBytes, assembler, sequenceDrops, totalBytes)
                windowStart = now; windowCompleted = 0; windowBytes = 0
            }
        }
    }

    private fun publishLatestEncoded(frame: EncodedFrame) {
        val replaced = latestEncoded.getAndSet(frame)
        if (replaced != null) {
            latencySkips.incrementAndGet()
            releaseEncoded(replaced)
        }
        if (decodeSignal.availablePermits() == 0) decodeSignal.release()
    }

    private fun releaseEncoded(frame: EncodedFrame?) {
        if (frame != null) jpegPool.release(frame.jpeg)
    }

    private fun decodeLoop(sessionId: Long) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_DISPLAY)
        val options = BitmapFactory.Options().apply {
            inScaled = false
            inDither = false
            inMutable = true
            inPreferredConfig = Bitmap.Config.RGB_565
        }

        while (isSessionActive(sessionId)) {
            try { if (!decodeSignal.tryAcquire(100, TimeUnit.MILLISECONDS)) continue }
            catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
            decodeSignal.drainPermits()

            var encoded = latestEncoded.getAndSet(null) ?: continue
            while (true) {
                val newer = latestEncoded.getAndSet(null) ?: break
                releaseEncoded(encoded)
                encoded = newer
                latencySkips.incrementAndGet()
            }

            try {
                val bitmap = decodeBitmap(encoded, options)
                if (bitmap == null) {
                    decodeErrors.incrementAndGet()
                    continue
                }
                if (latestEncoded.get() != null) {
                    recycleBitmap(bitmap)
                    latencySkips.incrementAndGet()
                    continue
                }
                decodedSinceStats.incrementAndGet()
                lastDecodedAt.set(SystemClock.elapsedRealtime())
                try {
                    listener.onFrame(
                        DecodedFrame(bitmap, encoded.stream, encoded.frameId, encoded.width,
                            encoded.height, encoded.jpegQuality, encoded.jpegSize)
                    )
                } catch (error: Throwable) {
                    recycleBitmap(bitmap)
                    throw error
                }
            } catch (error: OutOfMemoryError) {
                decodeErrors.incrementAndGet()
                notifyState("Mémoire vidéo insuffisante", true)
                try { Thread.sleep(200) } catch (_: InterruptedException) { break }
            } catch (error: Throwable) {
                decodeErrors.incrementAndGet()
                notifyState("Décodage impossible : ${error.safeMessage()}", true)
            } finally {
                releaseEncoded(encoded)
            }
        }
    }

    private fun decodeBitmap(encoded: EncodedFrame, options: BitmapFactory.Options): Bitmap? {
        val reusable = acquireBitmap()
        options.inBitmap = reusable
        return try {
            val decoded = BitmapFactory.decodeByteArray(encoded.jpeg, 0, encoded.jpegSize, options)
            if (reusable != null && decoded !== reusable) recycleBitmap(reusable)
            decoded
        } catch (_: IllegalArgumentException) {
            if (reusable != null && !reusable.isRecycled) reusable.recycle()
            options.inBitmap = null
            BitmapFactory.decodeByteArray(encoded.jpeg, 0, encoded.jpegSize, options)
        } finally {
            options.inBitmap = null
        }
    }

    private fun publishStats(
        now: Long,
        windowStart: Long,
        completedFrames: Long,
        bytes: Long,
        assembler: FrameAssembler,
        sequenceDrops: Long,
        totalBytes: Long
    ) {
        val elapsed = (now - windowStart).coerceAtLeast(1L) / 1_000.0
        val decoded = decodedSinceStats.getAndSet(0)
        val lastFrame = lastDecodedAt.get()
        try {
            listener.onStats(
                StreamStats(
                    receiveFps = completedFrames / elapsed,
                    displayFps = decoded / elapsed,
                    megabitsPerSecond = (bytes * 8.0 / 1_000_000.0) / elapsed,
                    droppedFrames = sequenceDrops + assembler.timedOutFrames + assembler.invalidFrames +
                        assembler.staleFrames + decodeErrors.get(),
                    skippedForLatency = latencySkips.get(),
                    totalMegabytes = totalBytes / (1024.0 * 1024.0),
                    millisecondsSinceLastFrame = if (lastFrame == 0L) Long.MAX_VALUE else now - lastFrame
                )
            )
        } catch (_: Throwable) {}
    }

    private fun notifyState(message: String, isError: Boolean) {
        try { listener.onState(message, isError) } catch (_: Throwable) {}
    }

    private fun setThreadPrioritySafely(priority: Int) {
        try { Process.setThreadPriority(priority) } catch (_: Throwable) {}
    }

    private fun Throwable.safeMessage(): String = message ?: javaClass.simpleName
}

data class DecodedFrame(
    val bitmap: Bitmap,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int,
    val jpegBytes: Int
)

data class StreamStats(
    val receiveFps: Double,
    val displayFps: Double,
    val megabitsPerSecond: Double,
    val droppedFrames: Long,
    val skippedForLatency: Long,
    val totalMegabytes: Double,
    val millisecondsSinceLastFrame: Long
)
