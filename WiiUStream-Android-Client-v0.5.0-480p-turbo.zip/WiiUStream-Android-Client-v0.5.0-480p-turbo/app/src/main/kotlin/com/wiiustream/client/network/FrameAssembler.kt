package com.wiiustream.client.network

/**
 * Low-latency assembler using fixed-size pooled JPEG buffers.
 * Only the newest frame for each stream is retained.
 */
internal class FrameAssembler(private val bufferPool: JpegBufferPool) {
    private val pending = HashMap<Int, PendingFrame>(2)
    private val newestSeen = HashMap<Int, Long>(2)

    var timedOutFrames: Long = 0
        private set
    var invalidFrames: Long = 0
        private set
    var staleFrames: Long = 0
        private set

    fun accept(header: VideoHeader, packet: ByteArray): EncodedFrame? {
        val nowNs = System.nanoTime()
        cleanupExpired(nowNs)

        val newest = newestSeen[header.stream]
        when {
            newest == null -> newestSeen[header.stream] = header.frameId
            StreamProtocol.isNewerFrame(header.frameId, newest) -> {
                newestSeen[header.stream] = header.frameId
                val stale = pending.remove(header.stream)
                if (stale != null) {
                    stale.release(bufferPool)
                    staleFrames++
                }
            }
            header.frameId != newest -> return null
        }

        var frame = pending[header.stream]
        if (frame == null || frame.header.frameId != header.frameId) {
            frame = PendingFrame(header, nowNs, bufferPool.acquire())
            pending[header.stream] = frame
        } else if (!frame.matches(header)) {
            pending.remove(header.stream)?.release(bufferPool)
            invalidFrames++
            return null
        }

        if (!frame.received[header.chunkIndex]) {
            val destinationOffset = header.chunkIndex * StreamProtocol.VIDEO_PAYLOAD_SIZE
            val sourceOffset = StreamProtocol.VIDEO_HEADER_SIZE
            if (destinationOffset + header.payloadSize > header.frameSize) {
                pending.remove(header.stream)?.release(bufferPool)
                invalidFrames++
                return null
            }
            packet.copyInto(
                destination = frame.jpeg,
                destinationOffset = destinationOffset,
                startIndex = sourceOffset,
                endIndex = sourceOffset + header.payloadSize
            )
            frame.received[header.chunkIndex] = true
            frame.receivedChunks++
            frame.receivedBytes += header.payloadSize
        }

        if (frame.receivedChunks != frame.header.chunkCount) return null
        pending.remove(header.stream)

        if (frame.receivedBytes != frame.header.frameSize) {
            frame.release(bufferPool)
            invalidFrames++
            return null
        }

        return EncodedFrame(
            jpeg = frame.jpeg,
            jpegSize = frame.header.frameSize,
            stream = frame.header.stream,
            frameId = frame.header.frameId,
            width = frame.header.width,
            height = frame.header.height,
            jpegQuality = frame.header.jpegQuality
        )
    }

    fun cleanupExpired(nowNs: Long = System.nanoTime()) {
        val iterator = pending.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (nowNs - entry.value.createdAtNs > StreamProtocol.FRAME_TIMEOUT_NS) {
                entry.value.release(bufferPool)
                iterator.remove()
                timedOutFrames++
            }
        }
    }

    fun clear() {
        pending.values.forEach { it.release(bufferPool) }
        pending.clear()
        newestSeen.clear()
    }

    private class PendingFrame(
        val header: VideoHeader,
        val createdAtNs: Long,
        val jpeg: ByteArray
    ) {
        val received = BooleanArray(header.chunkCount)
        var receivedChunks = 0
        var receivedBytes = 0

        fun matches(other: VideoHeader): Boolean =
            header.frameId == other.frameId &&
                header.frameSize == other.frameSize &&
                header.chunkCount == other.chunkCount &&
                header.stream == other.stream &&
                header.width == other.width &&
                header.height == other.height &&
                header.jpegQuality == other.jpegQuality

        fun release(pool: JpegBufferPool) = pool.release(jpeg)
    }
}

internal data class EncodedFrame(
    val jpeg: ByteArray,
    val jpegSize: Int,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int
)
