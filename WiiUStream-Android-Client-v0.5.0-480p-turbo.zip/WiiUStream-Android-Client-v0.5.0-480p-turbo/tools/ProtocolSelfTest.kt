package com.wiiustream.client.network

private fun writeU16(data: ByteArray, offset: Int, value: Int) {
    data[offset] = (value ushr 8).toByte()
    data[offset + 1] = value.toByte()
}

private fun writeU32(data: ByteArray, offset: Int, value: Long) {
    data[offset] = (value ushr 24).toByte()
    data[offset + 1] = (value ushr 16).toByte()
    data[offset + 2] = (value ushr 8).toByte()
    data[offset + 3] = value.toByte()
}

private fun packet(frame: ByteArray, frameId: Long, chunk: Int): ByteArray {
    val chunkCount = (frame.size + StreamProtocol.VIDEO_PAYLOAD_SIZE - 1) /
        StreamProtocol.VIDEO_PAYLOAD_SIZE
    val offset = chunk * StreamProtocol.VIDEO_PAYLOAD_SIZE
    val payload = minOf(StreamProtocol.VIDEO_PAYLOAD_SIZE, frame.size - offset)
    val result = ByteArray(StreamProtocol.VIDEO_HEADER_SIZE + payload)
    writeU32(result, 0, StreamProtocol.VIDEO_MAGIC.toLong())
    result[4] = StreamProtocol.VERSION.toByte()
    result[5] = 0
    result[6] = StreamProtocol.FLAG_NO_FRAME_CRC.toByte()
    result[7] = StreamProtocol.VIDEO_HEADER_SIZE.toByte()
    writeU32(result, 8, frameId)
    writeU32(result, 12, frame.size.toLong())
    writeU32(result, 16, 0)
    writeU16(result, 20, chunk)
    writeU16(result, 22, chunkCount)
    writeU16(result, 24, payload)
    writeU16(result, 26, 854)
    writeU16(result, 28, 480)
    result[30] = 34
    result[31] = 0
    frame.copyInto(result, StreamProtocol.VIDEO_HEADER_SIZE, offset, offset + payload)
    return result
}

fun main() {
    val hello = StreamProtocol.helloPacket(9445)
    check(hello.size == 12)
    check((hello[4].toInt() and 0xFF) == 2)

    val source = ByteArray(7_777) { ((it * 17) and 0xFF).toByte() }
    val packets = (0 until (source.size + StreamProtocol.VIDEO_PAYLOAD_SIZE - 1) /
        StreamProtocol.VIDEO_PAYLOAD_SIZE).map { packet(source, 123, it) }.reversed()

    val pool = JpegBufferPool()
    val assembler = FrameAssembler(pool)
    var completed: EncodedFrame? = null
    for (bytes in packets) {
        val header = StreamProtocol.parseVideoHeader(bytes, bytes.size)
        check(header != null)
        val result = assembler.accept(header, bytes)
        if (result != null) completed = result
    }
    check(completed != null)
    check(completed!!.jpegSize == source.size)
    check(completed!!.jpeg.copyOf(completed!!.jpegSize).contentEquals(source))
    pool.release(completed!!.jpeg)

    val bad = packets.first().copyOf()
    bad[4] = 1
    check(StreamProtocol.parseVideoHeader(bad, bad.size) == null)
    println("Protocol v2 + pooled assembler self-test OK")
}
