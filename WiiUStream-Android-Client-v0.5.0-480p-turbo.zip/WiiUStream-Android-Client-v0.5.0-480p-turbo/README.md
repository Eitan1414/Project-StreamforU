# WiiUStream Android 480p Turbo v0.5.0

Client Android compatible uniquement avec le plugin Aroma **v0.5.0-480p-turbo** (protocole v2).

## Objectif

- 854 × 480
- 17 à 20 FPS lorsque le jeu, la Wii U et le Wi-Fi le permettent
- latence minimale : aucune file de plusieurs images

## Optimisations

- parseur UDP sans allocation `ByteBuffer`
- buffers JPEG fixes réutilisés
- bitmaps `RGB_565` réutilisés avec `inBitmap`
- réception, décodage et heartbeat séparés
- rendu stable sur le thread graphique avec `postInvalidateOnAnimation`
- aucune vérification CRC complète (le protocole v2 privilégie le débit local)

## Installation

Compile l'APK avec le workflow fourni, désinstalle l'ancienne version, puis installe le nouvel APK.
La Wii U et le téléphone doivent être sur le même réseau local.
