# Tests

Le test de protocole vérifie :

- paquet de contrôle v2
- en-tête vidéo v2 de 32 octets
- payload UDP de 1440 octets
- reconstruction 854×480 dans le désordre
- rejet des paquets v1 et des dimensions non valides

La fluidité réelle doit être validée sur Wii U et téléphone.
