# Protocole WiiUStream v2

- contrôle UDP : port 9444
- vidéo UDP : port 9445
- en-tête vidéo : 32 octets
- charge utile vidéo : 1440 octets maximum
- résolution acceptée : 854×480
- drapeau `0x01` : CRC d'image désactivé pour réduire le coût CPU

Le client v0.5.0 n'est pas compatible avec les plugins utilisant le protocole v1.
