# Vérifications effectuées

Le parseur du protocole et le reconstructeur d’images ont été compilés séparément avec Kotlin/JVM.

Cas testés :

- adresse IPv4 valide et invalide ;
- fragments reçus dans le désordre ;
- reconstruction exacte de la trame ;
- validation du CRC32 ;
- rejet d’une trame dont le CRC est incorrect.

La compilation Android finale doit être réalisée avec le workflow GitHub Actions fourni. Le fonctionnement réel dépend ensuite d’un test conjoint avec la Wii U et le plugin Aroma.
