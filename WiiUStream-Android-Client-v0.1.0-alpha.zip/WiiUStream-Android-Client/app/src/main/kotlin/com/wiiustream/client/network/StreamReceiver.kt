package com.wiiustream.client.network

import android.graphics.BitmapFactory
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

internal class StreamReceiver(
    private val listener: Listener,
    private val videoPort: Int = StreamProtocol.DEFAULT_VIDEO_PORT
) {
    interface Listener {
        fun onState(message: String, isError: Boolean = false)
        fun onFrame(frame: DecodedFrame)
        fun onStats(stats: StreamStats)
    }

    private val running = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val sessionCounter = AtomicLong(0)
    private val socketRef = AtomicReference<DatagramSocket?>()
    private val executor = Executors.newFixedThreadPool(2)

    fun start(ipAddress: String) {
        if (closed.get() || !running.compareAndSet(false, true)) return
        val sessionId = sessionCounter.incrementAndGet()

        executor.execute {
            var socket: DatagramSocket? = null
            try {
                val address = StreamProtocol.resolveIpv4(ipAddress)
                socket = DatagramSocket(null).apply {
                    reuseAddress = true
                    receiveBufferSize = 4 * 1024 * 1024
                    soTimeout = 300
                    bind(InetSocketAddress("0.0.0.0", videoPort))
                }
                socketRef.set(socket)
                listener.onState("Connecté à ${address.hostAddress} — attente du flux…")

                executor.execute { heartbeatLoop(sessionId, socket, address) }
                receiveLoop(sessionId, socket, FrameAssembler())
            } catch (error: Exception) {
                if (isSessionActive(sessionId)) {
                    listener.onState(
                        "Erreur réseau : ${error.message ?: error.javaClass.simpleName}",
                        true
                    )
                }
            } finally {
                socket?.close()
                socketRef.compareAndSet(socket, null)
                if (sessionCounter.get() == sessionId) {
                    running.set(false)
                }
            }
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        sessionCounter.incrementAndGet()
        socketRef.getAndSet(null)?.close()
        listener.onState("Déconnecté")
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        stop()
        executor.shutdownNow()
        executor.awaitTermination(500, TimeUnit.MILLISECONDS)
    }

    private fun isSessionActive(sessionId: Long): Boolean =
        running.get() && !closed.get() && sessionCounter.get() == sessionId

    private fun heartbeatLoop(sessionId: Long, socket: DatagramSocket, address: InetAddress) {
        val payload = StreamProtocol.helloPacket(videoPort)
        val packet = DatagramPacket(payload, payload.size, address, StreamProtocol.CONTROL_PORT)

        while (isSessionActive(sessionId) && !socket.isClosed) {
            try {
                socket.send(packet)
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) listener.onState("Connexion interrompue", true)
                break
            } catch (error: Exception) {
                if (isSessionActive(sessionId)) {
                    listener.onState("Battement de cœur impossible : ${error.message}", true)
                }
            }

            try {
                Thread.sleep(1_000)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
        }
    }

    private fun receiveLoop(
        sessionId: Long,
        socket: DatagramSocket,
        assembler: FrameAssembler
    ) {
        val buffer = ByteArray(StreamProtocol.MAX_DATAGRAM_SIZE)
        val decodeOptions = BitmapFactory.Options().apply {
            inScaled = false
            inDither = false
        }
        var completedFrames = 0L
        var decodedFrames = 0L
        var receivedBytes = 0L
        var windowFrames = 0L
        var windowBytes = 0L
        var windowStart = SystemClock.elapsedRealtime()
        var lastFrameAt = 0L

        while (isSessionActive(sessionId) && !socket.isClosed) {
            val packet = DatagramPacket(buffer, buffer.size)
            try {
                socket.receive(packet)
            } catch (_: SocketTimeoutException) {
                publishStatsIfNeeded(
                    assembler = assembler,
                    now = SystemClock.elapsedRealtime(),
                    windowStart = windowStart,
                    windowFrames = windowFrames,
                    windowBytes = windowBytes,
                    completedFrames = completedFrames,
                    decodedFrames = decodedFrames,
                    totalBytes = receivedBytes,
                    lastFrameAt = lastFrameAt
                )?.also {
                    listener.onStats(it.stats)
                    windowStart = it.newWindowStart
                    windowFrames = 0L
                    windowBytes = 0L
                }
                continue
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) {
                    listener.onState("Socket fermée : ${error.message}", true)
                }
                break
            }

            val packetLength = packet.length
            receivedBytes += packetLength
            windowBytes += packetLength
            val header = StreamProtocol.parseVideoHeader(buffer, packetLength) ?: continue
            val frame = assembler.accept(header, buffer) ?: continue
            completedFrames++

            val bitmap = BitmapFactory.decodeByteArray(
                frame.jpeg,
                0,
                frame.jpeg.size,
                decodeOptions
            ) ?: continue
            decodedFrames++
            windowFrames++
            lastFrameAt = SystemClock.elapsedRealtime()
            listener.onFrame(
                DecodedFrame(
                    bitmap = bitmap,
                    stream = frame.stream,
                    width = frame.width,
                    height = frame.height,
                    jpegQuality = frame.jpegQuality,
                    jpegBytes = frame.jpeg.size
                )
            )

            val now = SystemClock.elapsedRealtime()
            publishStatsIfNeeded(
                assembler = assembler,
                now = now,
                windowStart = windowStart,
                windowFrames = windowFrames,
                windowBytes = windowBytes,
                completedFrames = completedFrames,
                decodedFrames = decodedFrames,
                totalBytes = receivedBytes,
                lastFrameAt = lastFrameAt
            )?.also {
                listener.onStats(it.stats)
                windowStart = it.newWindowStart
                windowFrames = 0L
                windowBytes = 0L
            }
        }
    }

    private fun publishStatsIfNeeded(
        assembler: FrameAssembler,
        now: Long,
        windowStart: Long,
        windowFrames: Long,
        windowBytes: Long,
        completedFrames: Long,
        decodedFrames: Long,
        totalBytes: Long,
        lastFrameAt: Long
    ): StatsWindow? {
        val elapsed = now - windowStart
        if (elapsed < 1_000) return null
        val seconds = elapsed / 1_000.0
        return StatsWindow(
            stats = StreamStats(
                fps = windowFrames / seconds,
                megabitsPerSecond = (windowBytes * 8.0 / 1_000_000.0) / seconds,
                completedFrames = completedFrames,
                decodedFrames = decodedFrames,
                droppedFrames = assembler.timedOutFrames + assembler.invalidFrames,
                totalMegabytes = totalBytes / (1024.0 * 1024.0),
                millisecondsSinceLastFrame =
                    if (lastFrameAt == 0L) Long.MAX_VALUE else now - lastFrameAt
            ),
            newWindowStart = now
        )
    }

    private data class StatsWindow(val stats: StreamStats, val newWindowStart: Long)
}

internal data class DecodedFrame(
    val bitmap: android.graphics.Bitmap,
    val stream: Int,
    val width: Int,
    val height: Int,
    val jpegQuality: Int,
    val jpegBytes: Int
)

internal data class StreamStats(
    val fps: Double,
    val megabitsPerSecond: Double,
    val completedFrames: Long,
    val decodedFrames: Long,
    val droppedFrames: Long,
    val totalMegabytes: Double,
    val millisecondsSinceLastFrame: Long
)
