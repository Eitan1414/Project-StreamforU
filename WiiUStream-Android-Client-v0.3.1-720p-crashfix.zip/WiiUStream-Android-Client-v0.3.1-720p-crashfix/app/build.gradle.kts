plugins {
    id("com.android.application")
}

android {
    namespace = "com.wiiustream.client"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.wiiustream.client"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.3.1-720p-crashfix"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
