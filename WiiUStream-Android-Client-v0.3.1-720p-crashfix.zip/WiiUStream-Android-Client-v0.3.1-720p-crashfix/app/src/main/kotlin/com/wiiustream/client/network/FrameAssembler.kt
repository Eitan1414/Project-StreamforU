package com.wiiustream.client.network

/**
 * Low-latency frame assembler.
 *
 * Only the newest frame for each stream is retained. Payloads are copied
 * directly into their final JPEG buffer, avoiding one allocation per chunk
 * and avoiding a second full-frame concatenation.
 */
internal class FrameAssembler {
    private val pending = HashMap<Int, PendingFrame>(2)
    private val newestSeen = HashMap<Int, Long>(2)

    var timedOutFrames: Long = 0
        private set
    var invalidFrames: Long = 0
        private set
    var staleFrames: Long = 0
        private set

    fun accept(header: VideoHeader, packet: ByteArray): EncodedFrame? {
        val nowNs = System.nanoTime()
        cleanupExpired(nowNs)

        val newest = newestSeen[header.stream]
        when {
            newest == null -> newestSeen[header.stream] = header.frameId
            StreamProtocol.isNewerFrame(header.frameId, newest) -> {
                newestSeen[header.stream] = header.frameId
                pending.remove(header.stream)?.let { staleFrames++ }
            }
            header.frameId != newest -> return null
        }

        var frame = pending[header.stream]
        if (frame == null || frame.header.frameId != header.frameId) {
            frame = PendingFrame(header, nowNs)
            pending[header.stream] = frame
        } else if (!frame.matches(header)) {
            pending.remove(header.stream)
            invalidFrames++
            return null
        }

        if (!frame.received[header.chunkIndex]) {
            val destinationOffset = header.chunkIndex * StreamProtocol.VIDEO_PAYLOAD_SIZE
            val sourceOffset = StreamProtocol.VIDEO_HEADER_SIZE
            if (destinationOffset + header.payloadSize > frame.jpeg.size) {
                pending.remove(header.stream)
                invalidFrames++
                return null
            }
            packet.copyInto(
                destination = frame.jpeg,
                destinationOffset = destinationOffset,
                startIndex = sourceOffset,
                endIndex = sourceOffset + header.payloadSize
            )
            frame.received[header.chunkIndex] = true
            frame.receivedChunks++
            frame.receivedBytes += header.payloadSize
        }

        if (frame.receivedChunks != frame.header.chunkCount) return null
        pending.remove(header.stream)

        if (frame.receivedBytes != frame.header.frameSize) {
            invalidFrames++
            return null
        }

        return EncodedFrame(
            jpeg = frame.jpeg,
            expectedCrc32 = frame.header.frameCrc32,
            stream = frame.header.stream,
            frameId = frame.header.frameId,
            width = frame.header.width,
            height = frame.header.height,
            jpegQuality = frame.header.jpegQuality
        )
    }

    fun cleanupExpired(nowNs: Long = System.nanoTime()) {
        val iterator = pending.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (nowNs - entry.value.createdAtNs > StreamProtocol.FRAME_TIMEOUT_NS) {
                iterator.remove()
                timedOutFrames++
            }
        }
    }

    private class PendingFrame(
        val header: VideoHeader,
        val createdAtNs: Long
    ) {
        val jpeg = ByteArray(header.frameSize)
        val received = BooleanArray(header.chunkCount)
        var receivedChunks = 0
        var receivedBytes = 0

        fun matches(other: VideoHeader): Boolean =
            header.frameId == other.frameId &&
                header.frameSize == other.frameSize &&
                header.frameCrc32 == other.frameCrc32 &&
                header.chunkCount == other.chunkCount &&
                header.stream == other.stream &&
                header.width == other.width &&
                header.height == other.height &&
                header.jpegQuality == other.jpegQuality
    }
}

internal data class EncodedFrame(
    val jpeg: ByteArray,
    val expectedCrc32: Long,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int
)
