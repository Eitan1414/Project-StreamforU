package com.wiiustream.client.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.CRC32

internal class StreamReceiver(
    context: Context,
    private val listener: Listener,
    private val videoPort: Int = StreamProtocol.DEFAULT_VIDEO_PORT
) {
    interface Listener {
        fun onState(message: String, isError: Boolean = false)
        fun onFrame(frame: DecodedFrame)
        fun onStats(stats: StreamStats)
    }

    private val appContext = context.applicationContext
    private val running = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val sessionCounter = AtomicLong(0)
    private val socketRef = AtomicReference<DatagramSocket?>()
    private val latestEncoded = AtomicReference<EncodedFrame?>()
    private val decodeSignal = Semaphore(0)
    private val executor = Executors.newFixedThreadPool(3) { task ->
        Thread(task, "WiiUStream").apply { isDaemon = true }
    }

    private val latencySkips = AtomicLong(0)
    private val decodeErrors = AtomicLong(0)
    private val decodedSinceStats = AtomicLong(0)
    private val lastDecodedAt = AtomicLong(0)
    private val lastCompletedFrame = AtomicLong(-1)
    private var wifiLock: WifiManager.WifiLock? = null

    fun start(ipAddress: String) {
        if (closed.get() || !running.compareAndSet(false, true)) return
        val sessionId = sessionCounter.incrementAndGet()
        resetCounters()

        // Optional optimization only: failure must never prevent streaming.
        acquireLowLatencyWifiLockSafely()

        try {
            executor.execute {
                setThreadPrioritySafely(Process.THREAD_PRIORITY_MORE_FAVORABLE)
                var socket: DatagramSocket? = null
                try {
                    val address = StreamProtocol.resolveIpv4(ipAddress)
                    socket = DatagramSocket(null).apply {
                        reuseAddress = true
                        // A large socket buffer turns a short slowdown into visible lag.
                        receiveBufferSize = 256 * 1024
                        soTimeout = 50
                        bind(InetSocketAddress("0.0.0.0", videoPort))
                    }
                    socketRef.set(socket)
                    listener.onState(
                        "Connecté à ${address.hostAddress} — attente du flux 720p…"
                    )

                    executor.execute { heartbeatLoop(sessionId, socket, address) }
                    executor.execute { decodeLoop(sessionId) }
                    receiveLoop(sessionId, socket, address, FrameAssembler())
                } catch (error: Exception) {
                    if (isSessionActive(sessionId)) {
                        listener.onState(
                            "Erreur réseau : ${error.message ?: error.javaClass.simpleName}",
                            true
                        )
                    }
                } finally {
                    socket?.close()
                    socketRef.compareAndSet(socket, null)
                    latestEncoded.set(null)
                    decodeSignal.release()
                    if (sessionCounter.get() == sessionId) running.set(false)
                    releaseWifiLockSafely()
                }
            }
        } catch (error: RuntimeException) {
            running.set(false)
            releaseWifiLockSafely()
            listener.onState(
                "Impossible de démarrer la réception : ${error.message ?: error.javaClass.simpleName}",
                true
            )
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        sessionCounter.incrementAndGet()
        socketRef.getAndSet(null)?.close()
        latestEncoded.set(null)
        decodeSignal.release()
        releaseWifiLockSafely()
        listener.onState("Déconnecté")
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        stop()
        executor.shutdownNow()
        executor.awaitTermination(500, TimeUnit.MILLISECONDS)
    }

    private fun resetCounters() {
        latestEncoded.set(null)
        decodeSignal.drainPermits()
        latencySkips.set(0)
        decodeErrors.set(0)
        decodedSinceStats.set(0)
        lastDecodedAt.set(0)
        lastCompletedFrame.set(-1)
    }

    private fun isSessionActive(sessionId: Long): Boolean =
        running.get() && !closed.get() && sessionCounter.get() == sessionId

    private fun heartbeatLoop(sessionId: Long, socket: DatagramSocket, address: InetAddress) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_BACKGROUND)
        val payload = StreamProtocol.helloPacket(videoPort)
        val packet = DatagramPacket(payload, payload.size, address, StreamProtocol.CONTROL_PORT)

        while (isSessionActive(sessionId) && !socket.isClosed) {
            try {
                socket.send(packet)
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) listener.onState("Connexion interrompue", true)
                break
            } catch (error: Exception) {
                if (isSessionActive(sessionId)) {
                    listener.onState("Battement de cœur impossible : ${error.message}", true)
                }
            }

            try {
                Thread.sleep(1_000)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
        }
    }

    private fun receiveLoop(
        sessionId: Long,
        socket: DatagramSocket,
        expectedAddress: InetAddress,
        assembler: FrameAssembler
    ) {
        val buffer = ByteArray(StreamProtocol.MAX_DATAGRAM_SIZE)
        val packet = DatagramPacket(buffer, buffer.size)
        var receivedBytes = 0L
        var windowCompleted = 0L
        var windowBytes = 0L
        var windowStart = SystemClock.elapsedRealtime()
        var sequenceDrops = 0L

        while (isSessionActive(sessionId) && !socket.isClosed) {
            packet.length = buffer.size
            try {
                socket.receive(packet)
            } catch (_: SocketTimeoutException) {
                assembler.cleanupExpired()
                val now = SystemClock.elapsedRealtime()
                if (now - windowStart >= 1_000) {
                    publishStats(
                        now = now,
                        windowStart = windowStart,
                        completedFrames = windowCompleted,
                        bytes = windowBytes,
                        assembler = assembler,
                        sequenceDrops = sequenceDrops,
                        totalBytes = receivedBytes
                    )
                    windowStart = now
                    windowCompleted = 0
                    windowBytes = 0
                }
                continue
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) {
                    listener.onState("Socket fermée : ${error.message}", true)
                }
                break
            }

            if (packet.address != expectedAddress) continue
            val packetLength = packet.length
            receivedBytes += packetLength

            val header = StreamProtocol.parseVideoHeader(buffer, packetLength) ?: continue
            val completed = assembler.accept(header, buffer) ?: continue

            val previous = lastCompletedFrame.getAndSet(completed.frameId)
            if (previous >= 0) {
                val gap = (completed.frameId - previous) and 0xFFFF_FFFFL
                if (gap in 2L..0x7FFF_FFFFL) sequenceDrops += gap - 1
            }

            windowCompleted++
            windowBytes += completed.jpeg.size
            publishLatestEncoded(completed)

            val now = SystemClock.elapsedRealtime()
            if (now - windowStart >= 1_000) {
                publishStats(
                    now = now,
                    windowStart = windowStart,
                    completedFrames = windowCompleted,
                    bytes = windowBytes,
                    assembler = assembler,
                    sequenceDrops = sequenceDrops,
                    totalBytes = receivedBytes
                )
                windowStart = now
                windowCompleted = 0
                windowBytes = 0
            }
        }
    }

    private fun publishLatestEncoded(frame: EncodedFrame) {
        if (latestEncoded.getAndSet(frame) != null) latencySkips.incrementAndGet()
        decodeSignal.release()
    }

    private fun decodeLoop(sessionId: Long) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_DISPLAY)
        val options = BitmapFactory.Options().apply {
            inScaled = false
            inDither = false
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        while (isSessionActive(sessionId)) {
            try {
                if (!decodeSignal.tryAcquire(100, TimeUnit.MILLISECONDS)) continue
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
            decodeSignal.drainPermits()

            var encoded = latestEncoded.getAndSet(null) ?: continue
            while (true) {
                val newer = latestEncoded.getAndSet(null) ?: break
                encoded = newer
                latencySkips.incrementAndGet()
            }

            val crc = CRC32().apply { update(encoded.jpeg) }.value
            if (crc != encoded.expectedCrc32) {
                decodeErrors.incrementAndGet()
                continue
            }

            val bitmap = BitmapFactory.decodeByteArray(
                encoded.jpeg,
                0,
                encoded.jpeg.size,
                options
            )
            if (bitmap == null) {
                decodeErrors.incrementAndGet()
                continue
            }

            // If a newer compressed frame arrived during decoding, skip this
            // decoded bitmap rather than displaying an already stale image.
            if (latestEncoded.get() != null) {
                bitmap.recycle()
                latencySkips.incrementAndGet()
                continue
            }

            decodedSinceStats.incrementAndGet()
            lastDecodedAt.set(SystemClock.elapsedRealtime())
            listener.onFrame(
                DecodedFrame(
                    bitmap = bitmap,
                    stream = encoded.stream,
                    frameId = encoded.frameId,
                    width = encoded.width,
                    height = encoded.height,
                    jpegQuality = encoded.jpegQuality,
                    jpegBytes = encoded.jpeg.size
                )
            )
        }
    }

    private fun publishStats(
        now: Long,
        windowStart: Long,
        completedFrames: Long,
        bytes: Long,
        assembler: FrameAssembler,
        sequenceDrops: Long,
        totalBytes: Long
    ) {
        val elapsed = (now - windowStart).coerceAtLeast(1L) / 1_000.0
        val decoded = decodedSinceStats.getAndSet(0)
        val lastFrame = lastDecodedAt.get()
        listener.onStats(
            StreamStats(
                receiveFps = completedFrames / elapsed,
                displayFps = decoded / elapsed,
                megabitsPerSecond = (bytes * 8.0 / 1_000_000.0) / elapsed,
                droppedFrames = sequenceDrops + assembler.timedOutFrames +
                    assembler.invalidFrames + assembler.staleFrames + decodeErrors.get(),
                skippedForLatency = latencySkips.get(),
                totalMegabytes = totalBytes / (1024.0 * 1024.0),
                millisecondsSinceLastFrame =
                    if (lastFrame == 0L) Long.MAX_VALUE else now - lastFrame
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun acquireLowLatencyWifiLockSafely() {
        try {
            val existing = wifiLock
            if (existing != null && existing.isHeld) return

            val wifiManager =
                appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            val lock = wifiManager.createWifiLock(mode, "WiiUStream:LowLatency")
            lock.setReferenceCounted(false)
            lock.acquire()
            wifiLock = lock
        } catch (_: SecurityException) {
            // Optional optimization only. The UDP stream works without it.
            wifiLock = null
        } catch (_: UnsupportedOperationException) {
            wifiLock = null
        } catch (_: IllegalArgumentException) {
            wifiLock = null
        } catch (_: RuntimeException) {
            // Protect against manufacturer-specific WifiManager failures.
            wifiLock = null
        }
    }

    private fun releaseWifiLockSafely() {
        val lock = wifiLock
        wifiLock = null
        if (lock == null) return
        try {
            if (lock.isHeld) lock.release()
        } catch (_: RuntimeException) {
            // Ignore an unavailable/already released manufacturer Wi-Fi lock.
        }
    }

    private fun setThreadPrioritySafely(priority: Int) {
        try {
            Process.setThreadPriority(priority)
        } catch (_: SecurityException) {
            // The default thread priority is sufficient.
        } catch (_: IllegalArgumentException) {
            // The default thread priority is sufficient.
        }
    }

}

data class DecodedFrame(
    val bitmap: Bitmap,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int,
    val jpegBytes: Int
)

data class StreamStats(
    val receiveFps: Double,
    val displayFps: Double,
    val megabitsPerSecond: Double,
    val droppedFrames: Long,
    val skippedForLatency: Long,
    val totalMegabytes: Double,
    val millisecondsSinceLastFrame: Long
)
