package com.wiiustream.client

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.wiiustream.client.network.DecodedFrame
import com.wiiustream.client.network.StreamProtocol
import com.wiiustream.client.network.StreamReceiver
import com.wiiustream.client.network.StreamStats
import com.wiiustream.client.ui.StreamView
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : Activity(), StreamReceiver.Listener {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val connected = AtomicBoolean(false)
    private val receivedFirstFrame = AtomicBoolean(false)
    private val lastFrameInfoUpdate = AtomicLong(0)

    private lateinit var root: FrameLayout
    private lateinit var streamView: StreamView
    private lateinit var controls: LinearLayout
    private lateinit var ipInput: EditText
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var overlayText: TextView
    private lateinit var receiver: StreamReceiver

    private var controlsVisible = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        receiver = StreamReceiver(applicationContext, this)
        restoreIp()
        updateConnectionUi(false)
    }

    override fun onStop() {
        super.onStop()
        disconnect()
    }

    override fun onDestroy() {
        receiver.close()
        super.onDestroy()
    }

    override fun onState(message: String, isError: Boolean) {
        mainHandler.post {
            statusText.text = message
            statusText.setTextColor(getColor(if (isError) R.color.error else R.color.text_secondary))
            if (isError) {
                connected.set(false)
                receivedFirstFrame.set(false)
                updateConnectionUi(false)
                overlayText.visibility = View.VISIBLE
                overlayText.text = message
            }
        }
    }

    override fun onFrame(frame: DecodedFrame) {
        if (!connected.get()) {
            if (!frame.bitmap.isRecycled) frame.bitmap.recycle()
            return
        }

        streamView.renderFrame(frame.bitmap)
        if (!frame.bitmap.isRecycled) frame.bitmap.recycle()

        val first = receivedFirstFrame.compareAndSet(false, true)
        val now = SystemClock.elapsedRealtime()
        val shouldUpdateInfo = first || now - lastFrameInfoUpdate.get() >= 250
        if (!shouldUpdateInfo) return
        lastFrameInfoUpdate.set(now)

        mainHandler.post {
            if (first) {
                overlayText.visibility = View.GONE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
            val source = if (frame.stream == 1) "TV" else "GamePad"
            statusText.text = String.format(
                Locale.US,
                "%s • %dx%d • JPEG %d%% • %.1f KiB",
                source,
                frame.width,
                frame.height,
                frame.jpegQuality,
                frame.jpegBytes / 1024.0
            )
            statusText.setTextColor(getColor(R.color.text_secondary))
        }
    }

    override fun onStats(stats: StreamStats) {
        mainHandler.post {
            val state = when {
                stats.millisecondsSinceLastFrame == Long.MAX_VALUE -> "aucune image"
                stats.millisecondsSinceLastFrame > 2_000 -> "flux interrompu"
                else -> "réception active"
            }
            statsText.text = String.format(
                Locale.US,
                "reçu %.1f FPS • affiché %.1f FPS • %.2f Mbit/s\npertes %d • retard évité %d • %s",
                stats.receiveFps,
                stats.displayFps,
                stats.megabitsPerSecond,
                stats.droppedFrames,
                stats.skippedForLatency,
                state
            )
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(getColor(R.color.background))
        }

        streamView = StreamView(this).apply {
            setOnClickListener { toggleControls() }
        }
        root.addView(
            streamView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        overlayText = TextView(this).apply {
            text = getString(R.string.waiting)
            setTextColor(getColor(R.color.text_secondary))
            textSize = 18f
            gravity = Gravity.CENTER
        }
        root.addView(
            overlayText,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xE6171D26.toInt())
        }

        val title = TextView(this).apply {
            text = "Wii U Stream — 720p Low Latency"
            setTextColor(getColor(R.color.text_primary))
            setTypeface(typeface, Typeface.BOLD)
            textSize = 20f
        }
        controls.addView(title)

        val connectionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        ipInput = EditText(this).apply {
            hint = getString(R.string.wiiu_ip_hint)
            setHintTextColor(getColor(R.color.text_secondary))
            setTextColor(getColor(R.color.text_primary))
            textSize = 16f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_PHONE
            setSelectAllOnFocus(false)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        connectionRow.addView(
            ipInput,
            LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                marginEnd = dp(10)
            }
        )

        connectButton = Button(this).apply {
            text = getString(R.string.connect)
            setOnClickListener {
                if (connected.get()) disconnect() else connect()
            }
        }
        connectionRow.addView(
            connectButton,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(52))
        )
        controls.addView(
            connectionRow,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )

        statusText = TextView(this).apply {
            setTextColor(getColor(R.color.text_secondary))
            textSize = 13f
        }
        controls.addView(
            statusText,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )

        statsText = TextView(this).apply {
            setTextColor(getColor(R.color.text_secondary))
            textSize = 12f
        }
        controls.addView(
            statsText,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(3) }
        )

        root.addView(
            controls,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )
        setContentView(root)
    }

    private fun connect() {
        val ip = ipInput.text.toString().trim()
        if (!StreamProtocol.isValidIpv4(ip)) {
            ipInput.error = "Adresse IPv4 invalide"
            return
        }

        getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_IP, ip)
            .apply()
        hideKeyboard()
        connected.set(true)
        receivedFirstFrame.set(false)
        lastFrameInfoUpdate.set(0)
        overlayText.visibility = View.VISIBLE
        overlayText.text = getString(R.string.waiting)
        statsText.text = ""
        updateConnectionUi(true)
        try {
            receiver.start(ip)
        } catch (error: RuntimeException) {
            connected.set(false)
            receivedFirstFrame.set(false)
            updateConnectionUi(false)
            overlayText.visibility = View.VISIBLE
            overlayText.text =
                "Connexion impossible : ${error.message ?: error.javaClass.simpleName}"
            statusText.text = overlayText.text
            statusText.setTextColor(getColor(R.color.error))
        }
    }

    private fun disconnect() {
        if (!connected.getAndSet(false)) return
        receiver.stop()
        receivedFirstFrame.set(false)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        showSystemBars()
        controlsVisible = true
        controls.visibility = View.VISIBLE
        overlayText.visibility = View.VISIBLE
        overlayText.text = getString(R.string.disconnected)
        streamView.clearFrame()
        statsText.text = ""
        updateConnectionUi(false)
    }

    private fun updateConnectionUi(isConnected: Boolean) {
        connectButton.text = getString(if (isConnected) R.string.disconnect else R.string.connect)
        ipInput.isEnabled = !isConnected
        if (!isConnected && statusText.text.isBlank()) {
            statusText.text = getString(R.string.disconnected)
        }
    }

    private fun toggleControls() {
        if (!connected.get() || !receivedFirstFrame.get()) return
        controlsVisible = !controlsVisible
        controls.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        if (controlsVisible) showSystemBars() else hideSystemBars()
    }

    private fun hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.apply {
                hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    private fun showSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.show(
                WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
            )
        } else {
            @Suppress("DEPRECATION")
            run { window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE }
        }
    }

    private fun restoreIp() {
        ipInput.setText(
            getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                .getString(KEY_IP, "")
                .orEmpty()
        )
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(ipInput.windowToken, 0)
        ipInput.clearFocus()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val PREFERENCES = "wiiu_stream"
        private const val KEY_IP = "wiiu_ip"
    }
}
